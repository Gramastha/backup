/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.psl.day6;

/**
 *
 * 
 */
public class Node<E> {
    private E data;
    private Node link;

    public Node(E data, Node link) {
        this.data = data;
        this.link = link;
    }

    public Node() {
        super();
    }

    public E getData() {
        return data;
    }

    public void setData(E data) {
        this.data = data;
    }

    public Node getLink() {
        return link;
    }

    public void setLink(Node link) {
        this.link = link;
    }
    
    
    
    
    
}
