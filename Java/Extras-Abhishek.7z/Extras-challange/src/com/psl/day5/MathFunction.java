package com.psl.day5;

public class MathFunction {

	public static void main(String[] args) {
		
		System.out.println(Math.ceil(12.58));
		System.out.println();
		System.out.println(Math.floor(12.58));
		System.out.println();
		System.out.println(Math.max(12.58, 1125.15));
		System.out.println();
		System.out.println(Math.min(12.58,0.25874));
		System.out.println();
		System.out.println(Math.pow(5,3));
		System.out.println();
		System.out.println(Math.sqrt(12.58));
		System.out.println();
	
		
		
		

	}

}
