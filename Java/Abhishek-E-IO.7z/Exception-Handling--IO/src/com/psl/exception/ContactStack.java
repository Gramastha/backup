package com.psl.exception;

import java.util.ArrayList;
import java.util.List;

public class ContactStack {
	
	private List<Contact> stack;
	int i=0;

    public ContactStack(int SIZE) 
    {
        stack = new ArrayList<Contact>(SIZE);
    }

    public void push(Contact c) 
    {

       stack.add(i++, c);
     }

     public Contact pop() throws Exception 
     { 
        if(!stack.isEmpty()){
           Contact c= stack.get(--i);
           stack.remove(i);
           return c;
        } else{
           throw new Exception("Stack Empty");
        }
     }

     


     public boolean isEmpty() 
     {
       return stack.isEmpty();
     }

 }


