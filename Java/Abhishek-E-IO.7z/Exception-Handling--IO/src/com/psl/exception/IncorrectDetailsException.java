package com.psl.exception;

public class IncorrectDetailsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6876802215301063045L;

	public IncorrectDetailsException(String msg) {
		super(msg);
		
	}
	
	

}
