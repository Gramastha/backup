package com.psl.IO;

import java.io.File;

public class FindFile {

	public static void main(String[] args) {
		Find("C:\\Users\\Administrator\\Downloads\\xyzz", "Assignment.docx");

	}
	public static void Find(String s,String fname){
		boolean flag=false;
		File f= new File(s);
		File[] f1= f.listFiles();
		if(f1.length==0)
			System.out.println("NO File Exists");
		else{
			for(File s1:f1){
				if(s1.isDirectory()){
					Find(s1.toString(), fname);
				}
				else {
					
					if(s1.getName().equalsIgnoreCase(fname))
					flag=true;
					
					
				}
				
			}
			
		}
		
		if(flag==true)
			System.out.println(fname+ " found");
		else
				System.out.println(fname+ " not found");
		
	}

}
