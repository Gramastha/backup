package com.psl.IO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Count {
	
	public static void main(String[] args){
		
		try {
			FileInputStream fs= new FileInputStream("abc.txt");
			int i,cnt=0;
			while((i=fs.read())!=-1){
				if(((char)i)==' '|| ((char)i)=='\n'){
					cnt++;
				}
			}
			
			System.out.println(cnt);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
