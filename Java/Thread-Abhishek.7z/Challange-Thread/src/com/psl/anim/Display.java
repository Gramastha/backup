package com.psl.anim;

import java.io.Console;
import java.io.IOException;

public class Display {

	public static void main(String[] args) {
		AnimationThread anim= new  AnimationThread();
		anim.start();
		
		
		
	}

}
