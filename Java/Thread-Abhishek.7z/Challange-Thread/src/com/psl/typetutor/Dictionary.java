package com.psl.typetutor;

public enum Dictionary {
	FIRE,EARTH,SKY,MOON,SUN,WIND,WATER,MERCURY,VENUS,MARS,JUPITOR,SATURN,NEPTUNE,PLUTO;
	

   
    public int getCount(){
        return Dictionary.values().length;
    }
}
